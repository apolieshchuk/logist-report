# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'files/ui/design_routes.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Routes(object):
    def setupUi(self, Routes):
        Routes.setObjectName("Routes")
        Routes.resize(379, 577)
        self.centralwidget = QtWidgets.QWidget(Routes)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.line_filter = QtWidgets.QLineEdit(self.centralwidget)
        self.line_filter.setObjectName("line_filter")
        self.verticalLayout_2.addWidget(self.line_filter)
        self.table_view = QtWidgets.QTableView(self.centralwidget)
        self.table_view.setObjectName("table_view")
        self.verticalLayout_2.addWidget(self.table_view)
        Routes.setCentralWidget(self.centralwidget)

        self.retranslateUi(Routes)
        QtCore.QMetaObject.connectSlotsByName(Routes)

    def retranslateUi(self, Routes):
        _translate = QtCore.QCoreApplication.translate
        Routes.setWindowTitle(_translate("Routes", "MainWindow"))

